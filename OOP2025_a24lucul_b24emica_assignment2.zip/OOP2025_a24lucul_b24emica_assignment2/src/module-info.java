module OOP2025_a24lucul_b24emica_assignment2 {
    requires java.base;
    requires java.se;
    requires it401g.todo;
	requires java.desktop;
    exports assignment2;
}